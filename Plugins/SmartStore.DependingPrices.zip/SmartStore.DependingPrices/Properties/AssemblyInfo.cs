﻿using System.Reflection;
[assembly: AssemblyTitle("SmartStore.DependingPrices")]
